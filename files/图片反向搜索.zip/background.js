chrome.runtime.onInstalled.addListener(() => {
  const menuItems = [
    { id: "google", title: "Google", url: "https://www.google.com/searchbyimage?client=app&image_url=" },
    { id: "googlelens", title: "Google Lens", url: "https://lens.google.com/uploadbyurl?url=" },
    { id: "yandexeu", title: "Yandex.eu", url: "https://yandex.eu/images/search?url=" },
    { id: "yandexru", title: "Yandex.ru", url: "https://yandex.ru/images/search?url=" },
    { id: "bing", title: "Bing", url: "https://www.bing.com/images/search?q=imgurl:" },
    { id: "tineye", title: "TinEye", url: "https://tineye.com/search/?url=" },

    { id: "3diqdb", title: "3D IQDB", url: "https://3d.iqdb.org/?url=" },
    { id: "iqdb", title: "IQDB", url: "https://iqdb.org/?url=" },
    { id: "saucenao", title: "SauceNAO", url: "https://saucenao.com/search.php?url=" },
    { id: "ascii2d", title: "ascii2d", url: "https://ascii2d.net/search/url/" },
    { id: "wait", title: "WAIT", url: "https://trace.moe/?url=" },
    { id: "trace", title: "Trace.moe", url: "https://trace.moe/?url=" },


    { id: "subscribe", title: "关注一下", url: "https://space.bilibili.com/3546816836537000/dynamic" }
  ];

  // 注册所有右键菜单项
  for (const item of menuItems) {
    chrome.contextMenus.create({
      id: item.id,
      title: item.title,
      contexts: ["image"]
    });
  }
});

// 点击菜单时打开对应搜索链接
chrome.contextMenus.onClicked.addListener((info, tab) => {
  const url = encodeURIComponent(info.srcUrl);
  let searchMap = {
    google: `https://www.google.com/searchbyimage?client=app&image_url=${url}`,
    googlelens: `https://lens.google.com/uploadbyurl?url=${url}`,
    yandexeu: `https://yandex.eu/images/search?url=${url}&rpt=imageview`,
    yandexru: `https://yandex.ru/images/search?url=${url}&rpt=imageview`,
    bing: `https://www.bing.com/images/search?q=imgurl:${url}&view=detailv2&iss=sbi`,
    tineye: `https://tineye.com/search/?url=${url}`,

    "3diqdb": `https://3d.iqdb.org/?url=${url}`,
    iqdb: `https://iqdb.org/?url=${url}`,
    saucenao: `https://saucenao.com/search.php?url=${url}`,
    ascii2d: `https://ascii2d.net/search/url/${url}`,
    wait: `https://trace.moe/?url=${url}`,
    trace: `https://trace.moe/?url=${url}`,


    subscribe: `https://space.bilibili.com/3546816836537000/dynamic`
  };

  const targetUrl = searchMap[info.menuItemId];
  if (targetUrl) {
    chrome.tabs.create({ url: targetUrl });
  }
});
